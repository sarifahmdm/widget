package com.apahipeh.myunit.footballplayer;

import android.content.Context;

import java.util.List;

class ListViewAdapter {
    public ListViewAdapter(List<PlayerItem> playerItemList, Context applicationContext) {
    }
}
