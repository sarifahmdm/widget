package com.apahipeh.myunit.footballplayer;

class PlayerItem {
    public PlayerItem(String no, String name, String position, String birth_date, String poster) {
    }
}
